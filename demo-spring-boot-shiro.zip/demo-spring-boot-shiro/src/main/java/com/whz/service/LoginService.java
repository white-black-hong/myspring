package com.whz.service;

import com.whz.bean.User;

/**
 * @auther whz
 * @create 2022-02-28 09:27
 */
public interface LoginService {

    public User getUserByName(String getMapByName);

}
